package com.asl.ia.notification.bean;

import org.springframework.stereotype.Component;

public class Holding {
	private String holdingName;

	public String getHoldingName() {
		return holdingName;
	}

	public void setHoldingName(String holdingName) {
		this.holdingName = holdingName;
	}
	
}
